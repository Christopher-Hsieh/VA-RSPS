public final class Class43 {

	public Class43(int i, int j, int k, int l, int i1, int j1, boolean flag, boolean tex) {
		aBoolean721 = true;
		anInt716 = i;
		anInt717 = j;
		anInt718 = k;
		anInt719 = l;
		anInt720 = i1;
		anInt722 = j1;
		aBoolean721 = flag;
		textured = tex;
	}

	public final int anInt716;
	public final int anInt717;
	public final int anInt718;
	public final int anInt719;
	public final int anInt720;
	public boolean aBoolean721;
	public final int anInt722;
	public final boolean textured;
}