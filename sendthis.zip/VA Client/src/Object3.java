// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public final class Object3
{

	public Object3()
	{
	}

	int anInt811;
	int anInt812;
	int anInt813;
	public Animable aClass30_Sub2_Sub4_814;
	public int uid;
	byte aByte816;
}
