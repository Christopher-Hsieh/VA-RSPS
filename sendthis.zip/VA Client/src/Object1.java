// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 


public final class Object1
{

	public Object1()
	{
	}

	int anInt273;
	int anInt274;
	int anInt275;
	int orientation;
	int orientation1;
	public Animable aClass30_Sub2_Sub4_278;
	public Animable aClass30_Sub2_Sub4_279;
	public int uid;
	byte aByte281;
}
